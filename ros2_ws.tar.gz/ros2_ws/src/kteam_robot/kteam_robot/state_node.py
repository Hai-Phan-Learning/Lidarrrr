#!/usr/bin/env python3

import math
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray


class StateNode(Node):

    def __init__(self):

        super().__init__('state_node')

        # ===============================
        # Parameters
        # ===============================
        self.declare_parameter('scan_topic', '/scan_rl')
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('num_rays', 24)
        self.declare_parameter('max_linear_speed', 0.22)    # m/s
        self.declare_parameter('goal_x', -4.5)
        self.declare_parameter('goal_y', 0.0)
        self.declare_parameter('sensor_timeout_sec', 1.0)   # an toàn phần cứng

        self.scan_topic = self.get_parameter('scan_topic').value
        self.odom_topic = self.get_parameter('odom_topic').value
        self.num_rays = self.get_parameter('num_rays').value
        self.max_linear_speed = self.get_parameter('max_linear_speed').value
        self.goal_x = self.get_parameter('goal_x').value
        self.goal_y = self.get_parameter('goal_y').value
        self.sensor_timeout_sec = self.get_parameter('sensor_timeout_sec').value

        # ===============================
        # LiDAR state
        # ===============================
        self.scan = [1.0] * self.num_rays
        self.scan_ready = False
        self.last_scan_time = None

        # ===============================
        # Publisher
        # ===============================
        self.state_pub = self.create_publisher(
            Float32MultiArray,
            '/rl_state',
            10
        )

        # ===============================
        # Subscribers
        # ===============================
        # QUAN TRỌNG: phải khớp QoS với scan_filter.py (BEST_EFFORT,
        # KEEP_LAST, depth=1) - nếu không sẽ không nhận được /scan_rl.
        scan_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.create_subscription(
            LaserScan,
            self.scan_topic,
            self.scan_callback,
            scan_qos
        )

        self.create_subscription(
            Odometry,
            self.odom_topic,
            self.odom_callback,
            10
        )

        self.counter = 0

        self.get_logger().info(
            f"RL State Node (REAL HARDWARE) Started | "
            f"scan_topic={self.scan_topic} | odom_topic={self.odom_topic}"
        )

    # =====================================================
    # /scan_rl đã đúng 24 tia, đã chuẩn hoá [0,1] sẵn từ
    # scan_filter.py -> chỉ cần lưu lại, không xử lý thêm.
    # =====================================================
    def scan_callback(self, msg):

        ranges = np.array(msg.ranges, dtype=np.float32)

        if len(ranges) != self.num_rays:
            self.get_logger().warn(
                f"Expected {self.num_rays} rays from {self.scan_topic}, "
                f"got {len(ranges)}"
            )
            return

        # Phòng hờ NaN/Inf dù scan_filter.py đã lọc, an toàn 2 lớp
        ranges = np.nan_to_num(
            ranges,
            nan=1.0,
            posinf=1.0,
            neginf=0.0
        )

        ranges = np.clip(ranges, 0.0, 1.0)

        self.scan = ranges.tolist()
        self.scan_ready = True
        self.last_scan_time = self.get_clock().now()

    # =====================================================
    def odom_callback(self, msg):

        if not self.scan_ready:
            return

        # An toàn phần cứng: nếu /scan_rl bị đứng/mất kết nối quá lâu
        # thì không publish state, tránh robot hành động dựa trên
        # dữ liệu cảm biến cũ.
        if self.last_scan_time is not None:
            age = (self.get_clock().now() - self.last_scan_time).nanoseconds / 1e9
            if age > self.sensor_timeout_sec:
                self.get_logger().warn(
                    f"/scan_rl quá cũ ({age:.2f}s) - bỏ qua state này"
                )
                return

        # -------------------------
        # Position
        # -------------------------
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        # -------------------------
        # Quaternion -> Yaw
        # -------------------------
        q = msg.pose.pose.orientation

        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        )

        # -------------------------
        # Distance
        # -------------------------
        distance = math.sqrt(
            (self.goal_x - x) ** 2 +
            (self.goal_y - y) ** 2
        )

        distance_norm = distance / 10.0
        distance_norm = np.clip(distance_norm, 0.0, 1.0)

        # -------------------------
        # Goal Angle
        # -------------------------
        desired_yaw = math.atan2(
            self.goal_y - y,
            self.goal_x - x
        )

        angle = desired_yaw - yaw

        angle = math.atan2(
            math.sin(angle),
            math.cos(angle)
        )

        angle_norm = angle / math.pi

        # -------------------------
        # Linear velocity
        # -------------------------
        linear = msg.twist.twist.linear.x

        linear_norm = linear / self.max_linear_speed
        linear_norm = np.clip(
            linear_norm,
            0.0,
            1.0
        )

        # -------------------------
        # 27-D RL State
        # -------------------------
        state = []

        state.extend(self.scan)

        state.append(float(distance_norm))
        state.append(float(angle_norm))
        state.append(float(linear_norm))

        state = np.array(state, dtype=np.float32)

        if np.isnan(state).any():
            self.get_logger().warn("NaN detected!")
            return

        msg_out = Float32MultiArray()
        msg_out.data = state.tolist()

        self.state_pub.publish(msg_out)

        # Debug mỗi 10 lần
        self.counter += 1

        if self.counter % 10 == 0:

            self.get_logger().info(
                f"Distance={distance_norm:.2f} | "
                f"Angle={angle_norm:.2f} | "
                f"V={linear_norm:.2f}"
            )


def main(args=None):

    rclpy.init(args=args)

    node = StateNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()