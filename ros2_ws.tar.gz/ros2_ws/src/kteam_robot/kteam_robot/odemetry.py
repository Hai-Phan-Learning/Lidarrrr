#!/usr/bin/env python3

import math
import threading

import serial

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, TransformStamped, Twist
from std_srvs.srv import Trigger
from tf2_ros import TransformBroadcaster


class OdometryNode(Node):

    def __init__(self):

        super().__init__('odometry_node')

        # ===============================
        # Parameters (đúng theo cấu hình bạn đưa)
        # ===============================
        self.declare_parameter('serial_port', '/dev/ttyACM0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('wheel_radius', 0.045)   # m
        self.declare_parameter('wheel_base', 0.24)       # m
        self.declare_parameter('ticks_per_rev', 616)
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('publish_tf', True)
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        self.serial_port = self.get_parameter('serial_port').value
        self.baudrate = self.get_parameter('baudrate').value
        self.wheel_radius = self.get_parameter('wheel_radius').value
        self.wheel_base = self.get_parameter('wheel_base').value
        self.ticks_per_rev = self.get_parameter('ticks_per_rev').value
        self.odom_topic = self.get_parameter('odom_topic').value
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.publish_tf = self.get_parameter('publish_tf').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value

        # Quãng đường đi được mỗi tick (m/tick)
        self.meters_per_tick = (2.0 * math.pi * self.wheel_radius) / self.ticks_per_rev

        # ===============================
        # Pose state
        # ===============================
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.last_left_ticks = None
        self.last_right_ticks = None
        self.last_time = self.get_clock().now()

        # Lock bảo vệ khi ghi Serial (đọc chạy ở thread nền, ghi chạy
        # ở thread callback ROS - tránh 2 thread ghi/đọc chồng nhau)
        self.serial_lock = threading.Lock()

        # ===============================
        # Publisher / TF broadcaster
        # ===============================
        self.odom_pub = self.create_publisher(Odometry, self.odom_topic, 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        # ===============================
        # Kết nối Serial tới Arduino
        # ===============================
        try:
            self.ser = serial.Serial(self.serial_port, self.baudrate, timeout=1.0)
            self.get_logger().info(
                f"Đã kết nối {self.serial_port} @ {self.baudrate} baud"
            )
        except serial.SerialException as e:
            self.get_logger().error(f"Không mở được cổng serial: {e}")
            raise

        # Đọc serial trong thread riêng để không block executor của ROS
        self.read_thread = threading.Thread(
            target=self.read_serial_loop,
            daemon=True
        )
        self.read_thread.start()

        # ===============================
        # Subscriber /cmd_vel -> gửi lệnh vận tốc bánh xuống Arduino
        # ===============================
        self.create_subscription(
            Twist,
            self.cmd_vel_topic,
            self.cmd_vel_callback,
            10
        )

        # ===============================
        # Service reset odometry về (0,0,0) - dùng khi test lặp lại
        # nhiều lần, không cần restart cả node mỗi lần
        # ===============================
        self.create_service(Trigger, 'reset_odom', self.reset_odom_callback)

        self.get_logger().info(
            f"Odometry Node Started | lắng nghe {self.cmd_vel_topic} | "
            f"gọi 'ros2 service call /reset_odom std_srvs/srv/Trigger' để reset vị trí về 0"
        )

    # =====================================================
    # Reset pose về (0,0,0) - KHÔNG reset last_left_ticks/
    # last_right_ticks vì tick encoder vẫn phải liên tục
    # (chỉ reset toạ độ tích luỹ x,y,theta)
    # =====================================================
    def reset_odom_callback(self, request, response):

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.get_logger().info("Đã reset odometry về (0, 0, 0)")

        response.success = True
        response.message = "Odometry reset to (0, 0, 0)"
        return response

    # =====================================================
    # Vòng lặp đọc dữ liệu Serial (chạy trong thread nền)
    # =====================================================
    def read_serial_loop(self):

        while rclpy.ok():

            try:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
            except Exception as e:
                self.get_logger().warn(f"Lỗi đọc serial: {e}")
                continue

            if not line:
                continue

            # ĐỊNH DẠNG GIẢ ĐỊNH từ Arduino: "L,R\n"
            # L, R = số tick encoder LŨY KẾ (cumulative) của bánh trái/phải.
            # -> Nếu Arduino của bạn gửi format khác, chỉ cần sửa hàm này.
            parts = line.split(',')

            if len(parts) != 2:
                continue

            try:
                left_ticks = int(parts[0])
                right_ticks = int(parts[1])

                self.get_logger().info(
                    f"RX -> L={left_ticks}, R={right_ticks}"
                )

            except ValueError:
                continue

            self.process_ticks(left_ticks, right_ticks)

    # =====================================================
    # Nhận /cmd_vel -> quy đổi ra vận tốc từng bánh (m/s) ->
    # gửi xuống Arduino qua Serial theo format "L_vel,R_vel\n"
    # =====================================================
    def cmd_vel_callback(self, msg):

        linear = msg.linear.x
        angular = msg.angular.z

        # Động học differential drive (nghịch đảo của odometry)
        left_vel = linear - (angular * self.wheel_base / 2.0)
        right_vel = linear + (angular * self.wheel_base / 2.0)

        line = f"{left_vel:.3f},{right_vel:.3f}\n"

        try:
            with self.serial_lock:
                self.ser.write(line.encode('utf-8'))
        except Exception as e:
            self.get_logger().warn(f"Lỗi gửi lệnh xuống Arduino: {e}")

    # =====================================================
    # Tính odometry từ số tick encoder
    # =====================================================
    def process_ticks(self, left_ticks, right_ticks):

        now = self.get_clock().now()

        if self.last_left_ticks is None:
            # Lần đầu tiên: chỉ lưu lại, chưa tính delta
            self.last_left_ticks = left_ticks
            self.last_right_ticks = right_ticks
            self.last_time = now
            return

        dt = (now - self.last_time).nanoseconds / 1e9

        if dt <= 0.0:
            return

        delta_left_ticks = left_ticks - self.last_left_ticks
        delta_right_ticks = right_ticks - self.last_right_ticks

        self.last_left_ticks = left_ticks
        self.last_right_ticks = right_ticks
        self.last_time = now

        # Quãng đường mỗi bánh đi được (m)
        d_left = delta_left_ticks * self.meters_per_tick
        d_right = delta_right_ticks * self.meters_per_tick

        # Động học differential drive
        d_center = (d_left + d_right) / 2.0
        d_theta = (d_right - d_left) / self.wheel_base

        # Cập nhật pose (tích phân midpoint cho chính xác hơn Euler thường)
        theta_mid = self.theta + d_theta / 2.0

        self.x += d_center * math.cos(theta_mid)
        self.y += d_center * math.sin(theta_mid)
        self.theta += d_theta

        # Chuẩn hóa theta về [-pi, pi]
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))

        # Vận tốc
        linear_vel = d_center / dt
        angular_vel = d_theta / dt

        # ---- DEBUG: kiểm tra vì sao distance không đổi ----
        self.get_logger().info(
            f"dL={delta_left_ticks} dR={delta_right_ticks} | "
            f"d_center={d_center:.4f} d_theta={d_theta:.4f} | "
            f"x={self.x:.4f} y={self.y:.4f}"
        )

        self.publish_odometry(now, linear_vel, angular_vel)

    # =====================================================
    # Publish nav_msgs/Odometry + TF (odom -> base_link)
    # =====================================================
    def publish_odometry(self, stamp, linear_vel, angular_vel):

        quat = self.yaw_to_quaternion(self.theta)
        stamp_msg = stamp.to_msg()

        # ---- Odometry message ----
        odom_msg = Odometry()
        odom_msg.header.stamp = stamp_msg
        odom_msg.header.frame_id = self.odom_frame
        odom_msg.child_frame_id = self.base_frame

        odom_msg.pose.pose.position.x = self.x
        odom_msg.pose.pose.position.y = self.y
        odom_msg.pose.pose.position.z = 0.0
        odom_msg.pose.pose.orientation = quat

        odom_msg.twist.twist.linear.x = linear_vel
        odom_msg.twist.twist.angular.z = angular_vel

        self.odom_pub.publish(odom_msg)

        # ---- TF: odom -> base_link ----
        if self.publish_tf:

            t = TransformStamped()
            t.header.stamp = stamp_msg
            t.header.frame_id = self.odom_frame
            t.child_frame_id = self.base_frame

            t.transform.translation.x = self.x
            t.transform.translation.y = self.y
            t.transform.translation.z = 0.0
            t.transform.rotation = quat

            self.tf_broadcaster.sendTransform(t)

    # =====================================================
    # Helper: yaw -> quaternion (chỉ xoay quanh trục Z)
    # =====================================================
    @staticmethod
    def yaw_to_quaternion(yaw):

        q = Quaternion()
        q.x = 0.0
        q.y = 0.0
        q.z = math.sin(yaw / 2.0)
        q.w = math.cos(yaw / 2.0)

        return q

    def destroy_node(self):
        if hasattr(self, 'ser') and self.ser.is_open:
            self.ser.close()
        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)

    node = OdometryNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()