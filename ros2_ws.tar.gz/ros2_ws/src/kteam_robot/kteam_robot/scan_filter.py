#!/usr/bin/env python3

import math
import numpy as np

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import LaserScan

from rclpy.qos import (
    QoSProfile,
    ReliabilityPolicy,
    HistoryPolicy
)

# ==========================================================
# PPO CONFIG (GIỮ GIỐNG LÚC TRAIN)
# ==========================================================

RL_MIN_ANGLE = -math.pi / 3.0          # -60 deg
RL_MAX_ANGLE = math.pi / 3.0           # +60 deg

RL_NUM_RAYS = 24

RL_MAX_RANGE = 3.5                     # giống lúc train

RL_ANGLE_INCREMENT = (RL_MAX_ANGLE - RL_MIN_ANGLE) / (RL_NUM_RAYS - 1)

WINDOW = 1                             # lấy min trong ±2 tia


class ScanFilter(Node):

    def __init__(self):

        super().__init__("scan_filter")

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.scan_sub = self.create_subscription(
            LaserScan,
            "/scan",
            self.scan_callback,
            qos
        )

        self.scan_pub = self.create_publisher(
            LaserScan,
            "/scan_rl",
            qos
        )

        self.scan_count = 0
        self.info_printed = False

        self.get_logger().info("===== Scan Filter Started =====")

    # ======================================================
    # Callback
    # ======================================================

    def scan_callback(self, msg):

        num_points = len(msg.ranges)

        if num_points == 0:
            return

        if not self.info_printed:

            self.get_logger().info("========== REAL LIDAR ==========")
            self.get_logger().info(f"Frame           : {msg.header.frame_id}")
            self.get_logger().info(f"Points          : {num_points}")
            self.get_logger().info(
                f"Angle min       : {math.degrees(msg.angle_min):.2f} deg")
            self.get_logger().info(
                f"Angle max       : {math.degrees(msg.angle_max):.2f} deg")
            self.get_logger().info(
                f"Angle increment : {math.degrees(msg.angle_increment):.4f} deg")
            self.get_logger().info(
                f"Range           : {msg.range_min:.2f} -> {msg.range_max:.2f} m")
            self.get_logger().info("================================")

            self.info_printed = True

        lidar24 = []

        for i in range(RL_NUM_RAYS):

            ##################################################
            # Góc PPO cần
            ##################################################

            angle = RL_MIN_ANGLE + i * RL_ANGLE_INCREMENT

            ##################################################
            # Chuyển sang index lidar thật
            ##################################################

            raw_index = (angle - msg.angle_min) / msg.angle_increment

            center = int(round(raw_index)) % num_points

            # ==================================================
            # XOAY LIDAR 180 ĐỘ
            # ==================================================
            center = (center + num_points // 2) % num_points

            ##################################################
            # Lấy min trong cửa sổ nhỏ
            ##################################################

            best = RL_MAX_RANGE

            for k in range(-WINDOW, WINDOW + 1):

                idx = (center + k) % num_points

                r = msg.ranges[idx]

                if math.isnan(r) or math.isinf(r):
                    continue

                if r < msg.range_min:
                    continue

                if r < best:
                    best = r

            ##################################################
            # Nếu toàn NaN
            ##################################################

            if best == RL_MAX_RANGE:
                best = RL_MAX_RANGE

            ##################################################
            # Clamp đúng môi trường train
            ##################################################

            best = min(best, RL_MAX_RANGE)

            ##################################################
            # Normalize
            ##################################################

            lidar24.append(best / RL_MAX_RANGE)

        ######################################################
        # Publish
        ######################################################

        out = LaserScan()

        out.header = msg.header

        out.angle_min = RL_MIN_ANGLE
        out.angle_max = RL_MAX_ANGLE
        out.angle_increment = RL_ANGLE_INCREMENT

        out.time_increment = msg.time_increment
        out.scan_time = msg.scan_time

        out.range_min = 0.0
        out.range_max = 1.0

        out.ranges = lidar24
        out.intensities = []

        self.scan_pub.publish(out)

        ######################################################
        # Debug mỗi ~1 giây
        ######################################################

        self.scan_count += 1

        if self.scan_count >= 6:

            self.scan_count = 0

            print("\n========== PPO INPUT ==========")
            print(np.round(np.array(lidar24), 3))
            print("================================\n")


def main(args=None):

    rclpy.init(args=args)

    node = ScanFilter()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()