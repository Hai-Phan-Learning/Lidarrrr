#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


class AvoidObstacle(Node):

    def __init__(self):

        super().__init__("avoid_obstacle")

        # ===============================
        # Parameters
        # ===============================
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')

        self.declare_parameter('flip_180', True)   # khớp scan_filter.py

        # Vùng góc (độ), 0 = phía trước, dương = bên trái, âm = bên phải
        self.declare_parameter('front_half_width_deg', 20.0)
        self.declare_parameter('left_min_deg', 40.0)
        self.declare_parameter('left_max_deg', 120.0)
        self.declare_parameter('right_min_deg', -120.0)
        self.declare_parameter('right_max_deg', -40.0)

        self.declare_parameter('safe_dist', 0.50)
        self.declare_parameter('danger_dist', 0.25)

        self.declare_parameter('forward_speed', 0.20)
        self.declare_parameter('turn_speed', 0.05)     # linear khi đang rẽ
        self.declare_parameter('angular_speed', 0.8)
        self.declare_parameter('escape_angular_speed', 1.2)
        self.declare_parameter('escape_linear_speed', -0.10)

        self.declare_parameter('max_range_default', 3.5)   # khi toàn NaN/Inf
        self.declare_parameter('sensor_timeout_sec', 1.0)  # watchdog an toàn

        self.scan_topic = self.get_parameter('scan_topic').value
        self.cmd_vel_topic = self.get_parameter('cmd_vel_topic').value
        self.flip_180 = self.get_parameter('flip_180').value

        self.front_half_width_deg = self.get_parameter('front_half_width_deg').value
        self.left_min_deg = self.get_parameter('left_min_deg').value
        self.left_max_deg = self.get_parameter('left_max_deg').value
        self.right_min_deg = self.get_parameter('right_min_deg').value
        self.right_max_deg = self.get_parameter('right_max_deg').value

        self.safe_dist = self.get_parameter('safe_dist').value
        self.danger_dist = self.get_parameter('danger_dist').value

        self.forward_speed = self.get_parameter('forward_speed').value
        self.turn_speed = self.get_parameter('turn_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.escape_angular_speed = self.get_parameter('escape_angular_speed').value
        self.escape_linear_speed = self.get_parameter('escape_linear_speed').value

        self.max_range_default = self.get_parameter('max_range_default').value
        self.sensor_timeout_sec = self.get_parameter('sensor_timeout_sec').value

        # ===============================
        # Publisher / Subscriber
        # ===============================
        self.publisher = self.create_publisher(
            Twist,
            self.cmd_vel_topic,
            10
        )

        # QUAN TRỌNG: khớp QoS với driver LiDAR thật (BEST_EFFORT)
        scan_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.subscription = self.create_subscription(
            LaserScan,
            self.scan_topic,
            self.scan_callback,
            scan_qos
        )

        # ===============================
        # Watchdog: dừng robot nếu mất scan quá lâu
        # ===============================
        self.last_scan_time = self.get_clock().now()
        self.watchdog_timer = self.create_timer(0.2, self.watchdog_check)

        self.get_logger().info(
            f"Obstacle Avoidance (REAL HARDWARE) Started | "
            f"scan_topic={self.scan_topic} | flip_180={self.flip_180}"
        )

    # ==================================================
    # Lấy khoảng cách nhỏ nhất trong 1 khoảng góc (độ)
    # ==================================================
    def get_zone_min(self, msg, angle_min_deg, angle_max_deg):

        num_points = len(msg.ranges)

        if num_points == 0:
            return self.max_range_default

        angle_min = math.radians(angle_min_deg)
        angle_max = math.radians(angle_max_deg)

        # Số điểm cần quét trong vùng góc này
        n_samples = max(
            2,
            int(round((angle_max - angle_min) / msg.angle_increment)) + 1
        )

        best = self.max_range_default
        found_valid = False

        for i in range(n_samples):

            angle = angle_min + i * (angle_max - angle_min) / (n_samples - 1)

            raw_index = (angle - msg.angle_min) / msg.angle_increment
            idx = int(round(raw_index)) % num_points

            # Áp dụng offset xoay 180 độ đã xác nhận từ scan_filter.py
            if self.flip_180:
                idx = (idx + num_points // 2) % num_points

            r = msg.ranges[idx]

            if not math.isfinite(r):
                continue
            if r < msg.range_min:
                continue

            found_valid = True
            if r < best:
                best = r

        return best if found_valid else self.max_range_default

    # ==================================================
    def watchdog_check(self):

        age = (self.get_clock().now() - self.last_scan_time).nanoseconds / 1e9

        if age > self.sensor_timeout_sec:
            self.get_logger().warn(
                f"Mất /scan quá {age:.2f}s - DỪNG ROBOT AN TOÀN"
            )
            self.publisher.publish(Twist())   # tất cả = 0

    # ==================================================
    def scan_callback(self, scan):

        self.last_scan_time = self.get_clock().now()

        cmd = Twist()

        # -----------------------------
        # Chia LiDAR thành 3 vùng theo GÓC THỰC (độ)
        # -----------------------------
        front = self.get_zone_min(
            scan, -self.front_half_width_deg, self.front_half_width_deg
        )
        left = self.get_zone_min(scan, self.left_min_deg, self.left_max_deg)
        right = self.get_zone_min(scan, self.right_min_deg, self.right_max_deg)

        # ---- DEBUG: chẩn đoán vì sao front luôn = max_range_default ----
        if not hasattr(self, '_debug_printed'):
            self._debug_printed = True
            num_points = len(scan.ranges)
            self.get_logger().info(
                f"[DEBUG] range_min={scan.range_min:.3f} range_max={scan.range_max:.3f} | "
                f"num_points={num_points} | angle_min={math.degrees(scan.angle_min):.1f} "
                f"angle_max={math.degrees(scan.angle_max):.1f}"
            )
            self.get_logger().info(
                f"[DEBUG] ranges[0:5]={[round(r,2) for r in scan.ranges[0:5]]}"
            )
            self.get_logger().info(
                f"[DEBUG] ranges[mid-2:mid+3]="
                f"{[round(r,2) for r in scan.ranges[num_points//2-2:num_points//2+3]]}"
            )

        SAFE = self.safe_dist
        DANGER = self.danger_dist

        # ==========================================================
        # 1. Trước mặt trống
        # ==========================================================
        if front > SAFE:
            cmd.linear.x = self.forward_speed
            cmd.angular.z = 0.0

        # ==========================================================
        # 2. Bị chặn phía trước
        # ==========================================================
        else:
            # Bị kẹt cả ba phía
            if front < DANGER and left < SAFE and right < SAFE:
                cmd.linear.x = self.escape_linear_speed
                if left > right:
                    cmd.angular.z = self.escape_angular_speed
                else:
                    cmd.angular.z = -self.escape_angular_speed
            # Rẽ trái
            elif left > right:
                cmd.linear.x = self.turn_speed
                cmd.angular.z = self.angular_speed
            # Rẽ phải
            else:
                cmd.linear.x = self.turn_speed
                cmd.angular.z = -self.angular_speed

        self.publisher.publish(cmd)

        self.get_logger().info(
            f"Front={front:.2f}  Left={left:.2f}  Right={right:.2f}"
        )


def main(args=None):

    rclpy.init(args=args)

    node = AvoidObstacle()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    # Dừng robot khi tắt node
    node.publisher.publish(Twist())

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()