#!/usr/bin/env python3
"""
PPO (ONNX Runtime) + Potential Field TỐI ƯU - Phiên bản cải tiến để tiếp cận đích tốt hơn
============================================================================
CÁC CẢI TIẾN CHÍNH:
1. Stall Detector mạnh hơn + hysteresis
2. Goal Angular Boost khi stall (phá limit cycle)
3. PF giảm dần khi gần đích
4. Logging chi tiết hơn
"""

import math
import os
from collections import deque
import numpy as np
import onnxruntime as ort
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Twist


class PPOPotentialFieldNode(Node):
    def __init__(self):
        super().__init__("ppo_agent")
        
        # ===============================
        # Load ONNX Model
        # ===============================
        self.declare_parameter(
            'model_path',
            os.path.expanduser("~/NCKH/ppo_onnx/ppo_onnx/ppo_turtlebot3_epfinal_shutdown2_v8.onnx")
        )
        model_path = self.get_parameter('model_path').value
        if not os.path.isfile(model_path):
            raise FileNotFoundError(f"Không tìm thấy file ONNX tại: {model_path}")

        available = ort.get_available_providers()
        providers = [p for p in ("TensorrtExecutionProvider", "CUDAExecutionProvider", "CPUExecutionProvider") 
                    if p in available]
        if not providers:
            providers = ["CPUExecutionProvider"]
            
        self.session = ort.InferenceSession(model_path, providers=providers)
        self.input_name = self.session.get_inputs()[0].name
        self.output_name = self.session.get_outputs()[0].name
        self.get_logger().info(f"Đã load ONNX model: {model_path} | providers={providers}")

        # Goal radius
        self.declare_parameter('goal_radius', 0.25)
        self.goal_radius = self.get_parameter('goal_radius').value
        self.goal_reached = False

        # PPO & Robot params
        self.v_max_train = 0.22
        self.w_max_train = 1.0

        # Potential Field params (đã tune)
        self.lidar_max_range = 3.5
        self.repulsion_gain = 1.0
        self.speed_floor_ratio = 0.35
        self.control_lag_buffer = 0.04
        self.declare_parameter('pf_weight', 0.4)
        self.pf_weight = self.get_parameter('pf_weight').value

        self.ray_angles = np.linspace(-math.pi / 3, math.pi / 3, 24)

        # Rectangular footprint
        self.half_length = 0.069
        self.half_width = 0.089
        cos_t = np.cos(self.ray_angles)
        sin_t = np.sin(self.ray_angles)
        with np.errstate(divide="ignore"):
            r_front = self.half_length / np.abs(cos_t)
            r_side = np.where(np.abs(sin_t) > 1e-6, self.half_width / np.abs(sin_t), np.inf)
        self.footprint_clearance = np.minimum(r_front, r_side)
        self.influence_margin = 0.35
        self.influence_radius_per_ray = self.footprint_clearance + self.control_lag_buffer + self.influence_margin

        # Kinematics
        self.declare_parameter('wheel_base', 0.24)
        self.declare_parameter('wheel_radius', 0.045)
        self.L = self.get_parameter('wheel_base').value
        self.r = self.get_parameter('wheel_radius').value
        self.declare_parameter('max_wheel_linear_speed', self.v_max_train)
        self.max_wheel_linear_speed = self.get_parameter('max_wheel_linear_speed').value

        self.get_logger().info(
            f"Robot params: L={self.L:.3f}m r={self.r:.3f}m max_wheel={self.max_wheel_linear_speed:.3f}m/s"
        )

        self.pub = self.create_publisher(Twist, "/cmd_vel", 10)

        # Subscription
        state_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )
        self.create_subscription(Float32MultiArray, "/rl_state", self.cb, state_qos)

        # Watchdog
        self.declare_parameter('sensor_timeout_sec', 1.0)
        self.sensor_timeout_sec = self.get_parameter('sensor_timeout_sec').value
        self.last_state_time = self.get_clock().now()
        self.create_timer(0.2, self.watchdog_check)

        # Stall Detector
        self.declare_parameter('stall_window_sec', 5.0)
        self.declare_parameter('stall_min_progress', 0.04)
        self.declare_parameter('stall_pf_weight', 0.08)
        self.stall_window_sec = self.get_parameter('stall_window_sec').value
        self.stall_min_progress = self.get_parameter('stall_min_progress').value
        self.stall_pf_weight = self.get_parameter('stall_pf_weight').value

        self.declare_parameter('goal_angular_boost', 0.65)
        self.goal_angular_boost = self.get_parameter('goal_angular_boost').value

        self._dist_history = deque(maxlen=100)
        self._is_stalled = False
        self._stall_counter = 0
        self._debug_counter = 0

        self.get_logger().info("=== PPO + PF OPTIMIZED (Anti Orbit) Started ===")

    def watchdog_check(self):
        age = (self.get_clock().now() - self.last_state_time).nanoseconds / 1e9
        if age > self.sensor_timeout_sec:
            self.get_logger().warn(f"Mất /rl_state {age:.2f}s → DỪNG ROBOT AN TOÀN")
            self.pub.publish(Twist())

    def _repulsion(self, lidar_norm: np.ndarray, distance_m: float):
        dists_m = lidar_norm * self.lidar_max_range
        clearance = dists_m - self.footprint_clearance
        min_clearance = float(np.min(clearance))

        # Giảm PF khi gần đích
        goal_damp = min(1.0, distance_m / 0.8)

        mask = dists_m < self.influence_radius_per_ray
        if not np.any(mask):
            return 0.0, 1.0

        strength = np.zeros_like(dists_m)
        norm_gap = np.clip(clearance - self.control_lag_buffer, 0.0, None) / np.maximum(self.influence_margin, 1e-6)
        strength[mask] = (1.0 - np.clip(norm_gap[mask], 0.0, 1.0)) ** 2

        angular_push = float(np.sum(-self.ray_angles * strength * (1.0 + 0.3 * np.abs(self.ray_angles))))
        angular_push *= self.repulsion_gain * goal_damp
        angular_push = float(np.clip(angular_push, -self.w_max_train * 0.8, self.w_max_train * 0.8))

        worst_norm_gap = float(np.clip((min_clearance - self.control_lag_buffer) / max(self.influence_margin, 1e-6), 0.0, 1.0))
        speed_scale = self.speed_floor_ratio + (1.0 - self.speed_floor_ratio) * worst_norm_gap

        return angular_push, float(np.clip(speed_scale, self.speed_floor_ratio, 1.0))

    def _clamp_wheel_feasible(self, v: float, w: float):
        v_r = v + w * self.L / 2.0
        v_l = v - w * self.L / 2.0
        max_req = max(abs(v_r), abs(v_l))
        if max_req > self.max_wheel_linear_speed and max_req > 1e-6:
            scale = self.max_wheel_linear_speed / max_req
            v *= scale
            w *= scale
            v_r = v + w * self.L / 2.0
            v_l = v - w * self.L / 2.0
        return v, w, v_l, v_r

    def cb(self, msg):
        self.last_state_time = self.get_clock().now()
        if self.goal_reached:
            self.pub.publish(Twist())
            return

        state = np.asarray(msg.data, dtype=np.float32)
        if len(state) == 28:
            state = state[:27]
        if len(state) != 27:
            self.get_logger().warn(f"State length error: {len(state)}")
            return

        distance_m = float(state[24]) * 10.0
        angle_to_goal = float(state[25])   # Giả sử index 25 là angle

        if distance_m <= self.goal_radius:
            self.goal_reached = True
            self.pub.publish(Twist())
            self.get_logger().info(f"✅ ĐÃ TỚI ĐÍCH! Distance = {distance_m:.3f}m")
            return

        # PPO inference
        state_batch = state.reshape(1, 27).astype(np.float32)
        outputs = self.session.run([self.output_name], {self.input_name: state_batch})
        action_vw = outputs[0][0]
        linear_ppo = float(action_vw[0])
        angular_ppo = float(action_vw[1])

        # Potential Field
        angular_push, speed_scale = self._repulsion(state[0:24], distance_m)

        # Stall detection
        now_sec = self.get_clock().now().nanoseconds / 1e9
        self._dist_history.append((now_sec, distance_m))
        while self._dist_history and now_sec - self._dist_history[0][0] > self.stall_window_sec:
            self._dist_history.popleft()

        was_stalled = self._is_stalled
        if len(self._dist_history) >= 8 and (now_sec - self._dist_history[0][0]) >= self.stall_window_sec - 0.5:
            window_dists = [d for _, d in self._dist_history]
            progress = max(window_dists) - min(window_dists)
            self._is_stalled = progress < self.stall_min_progress
        else:
            self._is_stalled = False

        if self._is_stalled and not was_stalled:
            self.get_logger().warn(f"STALL/ORBIT @ {distance_m:.2f}m | Angle={angle_to_goal:.2f} → Kích hoạt recovery")

        effective_pf_weight = self.stall_pf_weight if self._is_stalled else self.pf_weight

        # Command mixing
        linear_cmd = linear_ppo * speed_scale
        angular_cmd = angular_ppo + effective_pf_weight * angular_push

        # === GOAL BOOST KHI STALL ===
        if self._is_stalled and abs(angle_to_goal) > 0.12:
            boost = self.goal_angular_boost * np.sign(angle_to_goal) * (abs(angle_to_goal) ** 0.75)
            angular_cmd += boost
            if abs(angular_cmd) > 0.75:
                linear_cmd *= 0.7

        angular_cmd = float(np.clip(angular_cmd, -self.w_max_train, self.w_max_train))

        # Clamp kinematics
        linear_final, angular_final, v_l, v_r = self._clamp_wheel_feasible(linear_cmd, angular_cmd)

        # Publish
        t = Twist()
        t.linear.x = linear_final
        t.angular.z = angular_final
        self.pub.publish(t)

        # Debug
        self._debug_counter += 1
        if self._debug_counter % 8 == 0:
            status = "STALL" if self._is_stalled else "NORMAL"
            self.get_logger().info(
                f"PPO v={linear_ppo:.3f} w={angular_ppo:.3f} | "
                f"PF push={angular_push:.3f} scale={speed_scale:.2f} | "
                f"FINAL v={linear_final:.3f} w={angular_final:.3f} | "
                f"Dist={distance_m:.3f} Ang={angle_to_goal:.3f} | {status}"
            )


def main(args=None):
    rclpy.init(args=args)
    node = PPOPotentialFieldNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()