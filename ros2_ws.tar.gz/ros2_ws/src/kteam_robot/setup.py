from setuptools import setup
from glob import glob
import os

package_name = 'kteam_robot'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (
            os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')
        ),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='haiphan',
    maintainer_email='haiphan@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'scan_filter = kteam_robot.scan_filter:main',
            'state_node = kteam_robot.state_node:main',
            'odemetry = kteam_robot.odemetry:main',
            'avoid = kteam_robot.avoid:main',
            'ppo_agent = kteam_robot.ppo_agent:main',
        ],
    },
)
